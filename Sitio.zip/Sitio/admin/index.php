<?php
session_start();

if($_POST)
{

    if( ($_POST['administrador']=='ADMIN1597') && ($_POST['contrasenia']=='6325410.') )
    {
        $_SESSION['administrador']="ok";
        $_SESSION['nombreUsuario']="ADMIN1597";

        header('Location:inicio.php');
    }
    else
    {
        $message="Error: El usuario o contraseña son incorrectos.";
    }

    
}

/*
$sentenciaSQL=$conexion->prepare("SELECT * FROM usuario WHERE usuario=:usuario AND contrasenia=:contrasenia");
$sentenciaSQL->bindParam(":id", $txtID);
$sentenciaSQL->execute();
$usuario=$sentenciaSQL->fetch(PDO::FETCH_LAZY);

$nombreAdmin=$usuario['usuario'];
$contrasenia=$usuario['contrasenia'];
*/
?>

<!doctype html>
<html lang="en">
  <head>
    <title>Administrador</title>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.3.1/css/bootstrap.min.css" integrity="sha384-ggOyR0iXCbMQv3Xipma34MD+dH/1fQ784/j6cY/iJTQUOhcWr7x9JvoRxT2MZw1T" crossorigin="anonymous">
  </head>
  <body>

    <div class="container">
        <div class="row">

        <div class="col-md-4">
        </div>

            <div class="col-md-4">
</br></br></br></br>
                <div class="card">
                    <div class="card-header">
                        Login
                    </div>
                    <div class="card-body">

                    <?php if(isset($message)) { ?>
                        <div class="alert alert-danger" role="alert">
                            <?php echo $message; ?>
                        </div>
                    <?php } ?>
                        <form method="POST">

                        <div class = "form-group">
                        <label>Administrador</label>
                        <input type="text" class="form-control" name="administrador" placeholder="No. Identificador">
                        </div>

                        <div class="form-group">
                        <label>Contraseña</label>
                        <input type="password" class="form-control" name="contrasenia" id="exampleInputPassword1" placeholder="Contraseña">
                        </div>

                        <button type="submit" class="btn btn-primary">Sign In</button>

                        </form>
                        
                        


                    </div>

                </div>

            </div>
            
        </div>
    </div>

  

  </body>
</html>