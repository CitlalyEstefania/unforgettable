<?php include("template/superior.php"); ?>

                <div class="col-md-12">
                    <div class="jumbotron">
                        <h1 class="display-3">Bienvenid@</h1>
                        <p class="lead">¿List@ para publicar algo nuevo?</p>
                        <hr class="my-2">
                        <p>More info</p>
                        <p class="lead">
                            <a class="btn btn-primary btn-lg" href="seccion/publi.php" role="button">Administrar Blog</a>
                        </p>
                    </div>
                </div>
                
<?php include("template/inferior.php"); ?>