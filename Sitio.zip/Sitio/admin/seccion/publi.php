<?php include("../template/superior.php"); ?>
<?php

$txtID=(isset($_POST['txtID']))?$_POST['txtID']:"";
$txtTitulo=(isset($_POST['txtTitulo']))?$_POST['txtTitulo']:"";
$txtTexto=(isset($_POST['txtTexto']))?$_POST['txtTexto']:"";
$txtImagen=(isset($_FILES['txtImagen']['name']))?$_FILES['txtImagen']['name']:"";
$accion=(isset($_POST['accion']))?$_POST['accion']:"";

include("../config/bd.php");

switch($accion)
{
    case "Agregar":
        $sentenciaSQL=$conexion->prepare("INSERT INTO publi (titulo, texto, imagen ) VALUES (:titulo, :texto, :imagen);");
        $sentenciaSQL->bindParam(":titulo", $txtTitulo);
        $sentenciaSQL->bindParam(":texto", $txtTexto);

        $fecha= new DateTime();
        $nombreArchivo=($txtImagen!="")?$fecha->getTimestamp()."_".$_FILES["txtImagen"]["name"]:"imagen.jpg";

        $tmpImagen=$_FILES["txtImagen"]["tmp_name"];

        if($tmpImagen!="")
        {
                move_uploaded_file($tmpImagen,"../../img/".$nombreArchivo);
        }

        $sentenciaSQL->bindParam(":imagen", $nombreArchivo);
        $sentenciaSQL->execute();

        header("Location:publi.php");
        break;
        
    case "Modificar":

        $sentenciaSQL=$conexion->prepare("UPDATE publi SET titulo=:titulo WHERE id=:id");
        $sentenciaSQL->bindParam(":titulo", $txtTitulo);
        $sentenciaSQL->bindParam(":id", $txtID);
        $sentenciaSQL->execute();

        $sentenciaSQL=$conexion->prepare("UPDATE publi SET texto=:texto WHERE id=:id");
        $sentenciaSQL->bindParam(":texto", $txtTexto);
        $sentenciaSQL->bindParam(":id", $txtID);
        $sentenciaSQL->execute();

        if( $txtImagen != "" )
        {

            $fecha= new DateTime();
            $nombreArchivo=($txtImagen!="")?$fecha->getTimestamp()."_".$_FILES["txtImagen"]["name"]:"imagen.jpg";
            $tmpImagen=$_FILES["txtImagen"]["tmp_name"];

            move_uploaded_file($tmpImagen,"../../img/".$nombreArchivo);

            $sentenciaSQL=$conexion->prepare("SELECT imagen FROM publi WHERE id=:id");
            $sentenciaSQL->bindParam(":id", $txtID);
            $sentenciaSQL->execute();
            $publi=$sentenciaSQL->fetch(PDO::FETCH_LAZY);

            if( isset($publi["imagen"]) &&($publi["imagen"]!="imagen.jpg") )
            {
                if(file_exists("../../img/".$publi["imagen"]))
                {
                    unlink("../../img/".$publi["imagen"]);
                }
            }

            $sentenciaSQL=$conexion->prepare("UPDATE publi SET imagen=:imagen WHERE id=:id");
            $sentenciaSQL->bindParam(":imagen", $nombreArchivo);
            $sentenciaSQL->bindParam(":id", $txtID);
            $sentenciaSQL->execute();
        }

        header("Location:publi.php");
        break;

    case "Cancelar":
        
        header("Location:publi.php");

        //echo "Presionado botón cancelar";
        break;

    case "Seleccionar":

        $sentenciaSQL=$conexion->prepare("SELECT * FROM publi WHERE id=:id");
        $sentenciaSQL->bindParam(":id", $txtID);
        $sentenciaSQL->execute();
        $publi=$sentenciaSQL->fetch(PDO::FETCH_LAZY);

        $txtTitulo=$publi['titulo'];
        $txtTexto=$publi['texto'];
        $txtImagen=$publi['imagen'];

        //echo "Presionado botón seleccionar";
        break;

    case "Borrar":

        $sentenciaSQL=$conexion->prepare("SELECT imagen FROM publi WHERE id=:id");
        $sentenciaSQL->bindParam(":id", $txtID);
        $sentenciaSQL->execute();
        $publi=$sentenciaSQL->fetch(PDO::FETCH_LAZY);

        if( isset($publi["imagen"]) &&($publi["imagen"]!="imagen.jpg") )
        {
            if(file_exists("../../img/".$publi["imagen"]))
            {
                unlink("../../img/".$publi["imagen"]);
            }
        }

        $sentenciaSQL=$conexion->prepare("DELETE FROM publi WHERE id=:id");
        $sentenciaSQL->bindParam(":id", $txtID);
        $sentenciaSQL->execute();
        header("Location:publi.php");
        break;
}

$sentenciaSQL=$conexion->prepare("SELECT * FROM publi");
$sentenciaSQL->execute();
$listapubli=$sentenciaSQL->fetchAll(PDO::FETCH_ASSOC);

?>

<div class="col-md-8">

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>ID</th>
                <th>Título</th>
                <th>Texto</th>
                <th>Imagen</th>
                <th>Acciones</th>
            </tr>
        </thead>
        <tbody>
        <?php foreach($listapubli as $publi) { ?>
            <tr>
                <td><?php echo $publi["id"]; ?></td>
                <td><?php echo $publi["titulo"]; ?></td>
                <td><?php echo $publi["texto"]; ?></td>
                <td>
                
                <img class="img-thumbnail rounded" src="../../img/<?php echo $publi["imagen"]; ?>" width="50" alt="" srcset="">
                
                </td>

                <td>

                    <form method="post">

                        <input type="hidden" name="txtID" id="txtID" value="<?php echo $publi['id']; ?>" />
                        
                        <input type="submit" name="accion" value="Seleccionar" class="btn btn-primary"/>
        </br>
        <br/>
                        <input type="submit" name="accion" value="Borrar" class="btn btn-danger"/>

                    </form>

                </td>

            </tr>
        <?php } ?>
        </tbody>
    </table>

</div>

<div class="col-md-4">

    <div class="card">
<!--
        <div class="card-header">
            Publicaciones
        </div>
-->
        <div class="card-body">

            <form method="POST" enctype="multipart/form-data">

                <div class = "form-group">
                    <label for="txtID">ID</label>
                    <input type="text" required readonly class="form-control" value="<?php echo $txtID; ?>" name="txtID" id="txtID" placeholder="ID">
                </div>

                <div class = "form-group">
                    <label for="txtTitulo">Título</label>
                    <input type="text" required class="form-control" value="<?php echo $txtTitulo; ?>" name="txtTitulo" id="txtTitulo" placeholder="Titulo">
                </div>

                <div class = "form-group">
                    <label for="txtTexto">Texto</label>
                    <textarea class="form-control" required name="txtTexto" id="txtTexto" placeholder="Texto" rows="5"><?php echo $txtTexto; ?></textarea>
                    <!--<input type="text" class="form-control" value="?php echo $txtTexto; ?>" name="txtTexto" id="txtTexto" placeholder="Texto"> -->
                </div>

                <div class = "form-group">
                    <label for="txtImagen">Imagen</label>

                    <br/>

                    <?php    if($txtImagen!=""){  ?>

                        <img class="img-thumbnail rounded" src="../../img/<?php echo $txtImagen; ?>" width="50" alt="" srcset="">

                    <?php    } ?>

                    <input type="file" class="form-control" name="txtImagen" id="txtImagen" placeholder="Imagen">
                </div>

                <div class="btn-group" role="group" aria-label="">
                    <button type="submit" name="accion" <?php echo ($accion=="Seleccionar")?"disabled":""; ?> value="Agregar" class="btn btn-success">Agregar</button>
                    <button type="submit" name="accion" <?php echo ($accion!="Seleccionar")?"disabled":""; ?> value="Modificar" class="btn btn-warning">Modificar</button>
                    <button type="submit" name="accion" <?php echo ($accion!="Seleccionar")?"disabled":""; ?> value="Cancelar" class="btn btn-info">Cancelar</button>
                </div>
            </form>
        </div>
    </div>
</div>



<?php include("../template/inferior.php"); ?>