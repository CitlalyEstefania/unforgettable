<?php include("template/superior.php"); ?>

            <div class="jumbotron text-center">
                <h1 class="display-3">Bienvenidos a BlogModa</h1>
                <p class="lead">Aquí podrás encontrar novedades del mundo de la moda, conjuntos nuevos, tendencias y mucha más.</p>
                <hr class="my-2">
                <img width="500" src="img/147.jpg" class="img-thumbnail rounded mx-auto d-block"/>
                <br/>
                <p class="lead">
                    <a class="btn btn-primary btn-lg" href="temas.php" role="button">Explora nuestras recientes<br/> publicaciones</a>
                </p>
            </div>

<?php include("template/inferior.php"); ?>