<?php include("template/superior.php"); ?>


<div class="jumbotron">
    <h1 class="display-3">Acerca de nosotros</h1>
    <p class="lead">Lorem ipsum dolor sit amet, consectetur adipiscing elit. Fusce volutpat, nisi feugiat interdum viverra, dui lacus mattis purus, vitae consectetur enim massa et ipsum. In tempor commodo tristique.</p>
    <hr class="my-2">
    <br/>
</div>

<br/><br/>

<div class="col-md-4">

    <div class="card">

        <img class="card-img-top" src="img/U1.jpg" alt="">
        
        <div class="card-body">
            
            <h4 class="card-title">Persona 1</h4>
            <p class="card-text">Programador</p>
            
        </div>

    </div>
    <br/>
</div>

<div class="col-md-4">

    <div class="card">

        <img class="card-img-top" src="img/U2.jpg" alt="">
        
        <div class="card-body">
            
            <h4 class="card-title">Persona 2</h4>
            <p class="card-text">Desarrollador</p>
            
        </div>

    </div>
    <br/>
</div>

<div class="col-md-4">

    <div class="card">

        <img class="card-img-top" src="img/U1.jpg" alt="">
        
        <div class="card-body">
            
            <h4 class="card-title">Persona 3</h4>
            <p class="card-text">Diseñador</p>
            
        </div>

    </div>
    <br/>
</div>

<div class="col-md-4">

    <div class="card">

        <img class="card-img-top" src="img/U2.jpg" alt="">
        
        <div class="card-body">
            
            <h4 class="card-title">Persona 4</h4>
            <p class="card-text">Testeador</p>
            
        </div>

    </div>
    <br/>
</div>

<div class="col-md-4">

    <div class="card">

        <img class="card-img-top" src="img/U1.jpg" alt="">
        
        <div class="card-body">
            
            <h4 class="card-title">Persona 3</h4>
            <p class="card-text">Diseñador</p>
            
        </div>

    </div>
    <br/>
</div>

<div class="col-md-4">

    <div class="card">

        <img class="card-img-top" src="img/U2.jpg" alt="">
        
        <div class="card-body">
            
            <h4 class="card-title">Persona 4</h4>
            <p class="card-text">Testeador</p>
            
        </div>

    </div>
    <br/>
</div>

<?php include("template/inferior.php"); ?>